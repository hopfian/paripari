# Sitemap provenance for the JP census

The Crunchyroll sitemap is **geo-blocked from Japanese egress**: `sitemap.xml` and every
shard return HTTP 301 (Cloudflare) to the "currently-unavailable-in-your-location" block
page (verified 2026-10-31, see the JP browse-capture bundle for browser-level evidence;
the JP-run of stage 07 therefore recorded an empty inventory).

Sitemap content is global (identical regardless of fetching region), so this census uses
the fresh global snapshot fetched earlier the same day from the US egress
(`local/work-US/sitemaps/`, published in `provenance/sitemaps-2026.10-US.tar.gz`).

Fetched: 2026-10-31 (US egress) · Series URLs: 2,044 · Watch-page ids: 92,275.
